import { SentimentResult, Emotion, Sentiment } from '../types/sentiment';

/**
 * Analyzes text to determine sentiment and emotions
 * NOTE: This is a mock service in place of a real NLP API
 */
export async function analyzeText(text: string): Promise<SentimentResult> {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Simple keyword-based mock sentiment analysis
  const lowerText = text.toLowerCase();
  
  // Basic emotion detection based on keywords
  const emotions: Record<Emotion, number> = {
    joy: 0.1,
    sadness: 0.1,
    anger: 0.1,
    fear: 0.1,
    surprise: 0.1,
    love: 0.1,
    disgust: 0.1
  };

  // Emotion keyword mapping
  const emotionKeywords: Record<Emotion, string[]> = {
    joy: ['happy', 'joy', 'delight', 'excited', 'glad', 'great', 'wonderful', 'amazing', 'awesome', 'love', 'smile'],
    sadness: ['sad', 'unhappy', 'depressed', 'down', 'hurt', 'disappointed', 'miss', 'sorry', 'regret', 'cry'],
    anger: ['angry', 'mad', 'furious', 'hate', 'annoyed', 'frustrated', 'rage', 'upset', 'horrible', 'terrible'],
    fear: ['afraid', 'fear', 'scared', 'terrified', 'anxious', 'worried', 'nervous', 'concern', 'dread'],
    surprise: ['surprise', 'shocked', 'amazed', 'astonished', 'unexpected', 'wow', 'omg', 'suddenly'],
    love: ['love', 'adore', 'care', 'fond', 'affection', 'passion', 'heart', 'romance', 'cherish'],
    disgust: ['disgust', 'gross', 'ew', 'yuck', 'sick', 'nasty', 'dislike', 'revolting', 'offensive']
  };

  // Count emotion keywords and calculate scores
  let totalEmotionKeywords = 0;
  for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
    let count = 0;
    for (const keyword of keywords) {
      // Count occurrences of each keyword in the text
      const regex = new RegExp(`\\b${keyword}\\b|\\b${keyword}s\\b|\\b${keyword}ed\\b|\\b${keyword}ing\\b`, 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        count += matches.length;
      }
    }
    emotions[emotion as Emotion] = count;
    totalEmotionKeywords += count;
  }

  // Normalize emotion scores
  if (totalEmotionKeywords > 0) {
    for (const emotion in emotions) {
      emotions[emotion as Emotion] = emotions[emotion as Emotion] / totalEmotionKeywords;
    }
  } else {
    // If no emotions detected, assign random values with a dominant one
    const randomEmotion = Object.keys(emotions)[Math.floor(Math.random() * 7)] as Emotion;
    emotions[randomEmotion] = 0.4 + Math.random() * 0.3;
    
    let remainingProbability = 1 - emotions[randomEmotion];
    for (const emotion in emotions) {
      if (emotion !== randomEmotion) {
        const randomValue = Math.random() * 0.2;
        emotions[emotion as Emotion] = Math.min(randomValue, remainingProbability);
        remainingProbability -= emotions[emotion as Emotion];
      }
    }
  }

  // Calculate overall sentiment score (-1 to 1)
  const positiveKeywords = [
    'good', 'great', 'excellent', 'wonderful', 'fantastic', 
    'amazing', 'love', 'happy', 'joy', 'delighted', 'excited',
    'positive', 'beautiful', 'nice', 'perfect', 'thanks', 'thank you'
  ];
  
  const negativeKeywords = [
    'bad', 'terrible', 'awful', 'horrible', 'worst',
    'hate', 'sad', 'angry', 'upset', 'disappointed', 
    'negative', 'poor', 'sucks', 'boring', 'stupid', 'useless'
  ];

  let positiveScore = 0;
  let negativeScore = 0;

  for (const keyword of positiveKeywords) {
    const regex = new RegExp(`\\b${keyword}\\b|\\b${keyword}s\\b|\\b${keyword}ed\\b|\\b${keyword}ing\\b`, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      positiveScore += matches.length;
    }
  }

  for (const keyword of negativeKeywords) {
    const regex = new RegExp(`\\b${keyword}\\b|\\b${keyword}s\\b|\\b${keyword}ed\\b|\\b${keyword}ing\\b`, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      negativeScore += matches.length;
    }
  }

  // In case no keywords matched, add small random bias
  if (positiveScore === 0 && negativeScore === 0) {
    // Random score between -0.5 and 0.5
    const randomScore = Math.random() - 0.5;
    positiveScore = randomScore > 0 ? randomScore : 0;
    negativeScore = randomScore < 0 ? -randomScore : 0;
  }

  const total = positiveScore + negativeScore;
  const normalizedScore = total === 0 ? 0 : (positiveScore - negativeScore) / total;
  
  // Determine overall sentiment
  let sentiment: Sentiment;
  if (normalizedScore > 0.15) {
    sentiment = 'positive';
  } else if (normalizedScore < -0.15) {
    sentiment = 'negative';
  } else {
    sentiment = 'neutral';
  }

  // Random confidence between 70% and 95%
  const confidence = 0.7 + Math.random() * 0.25;

  return {
    text,
    score: normalizedScore,
    sentiment,
    emotions,
    confidence,
    timestamp: Date.now()
  };
}