import { SentimentResult } from '../types/sentiment';

// Mock data for history
const mockHistoryData: SentimentResult[] = [
  {
    text: "I'm so excited about this new product launch! It's going to be amazing!",
    score: 0.85,
    sentiment: 'positive',
    emotions: {
      joy: 0.7,
      sadness: 0.05,
      anger: 0.02,
      fear: 0.03,
      surprise: 0.15,
      love: 0.03,
      disgust: 0.02
    },
    confidence: 0.92,
    timestamp: Date.now() - 3600000 // 1 hour ago
  },
  {
    text: "The customer service was terrible. I waited for hours and nobody helped me.",
    score: -0.75,
    sentiment: 'negative',
    emotions: {
      joy: 0.02,
      sadness: 0.3,
      anger: 0.55,
      fear: 0.02,
      surprise: 0.03,
      love: 0.01,
      disgust: 0.07
    },
    confidence: 0.89,
    timestamp: Date.now() - 7200000 // 2 hours ago
  },
  {
    text: "Just got a new notification about my order. It should arrive tomorrow.",
    score: 0.1,
    sentiment: 'neutral',
    emotions: {
      joy: 0.2,
      sadness: 0.1,
      anger: 0.05,
      fear: 0.1,
      surprise: 0.4,
      love: 0.05,
      disgust: 0.1
    },
    confidence: 0.75,
    timestamp: Date.now() - 86400000 // 1 day ago
  },
  {
    text: "I absolutely love this app! The interface is so intuitive and it makes my life easier.",
    score: 0.95,
    sentiment: 'positive',
    emotions: {
      joy: 0.6,
      sadness: 0.01,
      anger: 0.01,
      fear: 0.01,
      surprise: 0.11,
      love: 0.25,
      disgust: 0.01
    },
    confidence: 0.94,
    timestamp: Date.now() - 172800000 // 2 days ago
  },
  {
    text: "Feeling really disappointed with the latest update. So many bugs and performance issues.",
    score: -0.65,
    sentiment: 'negative',
    emotions: {
      joy: 0.05,
      sadness: 0.4,
      anger: 0.3,
      fear: 0.05,
      surprise: 0.05,
      love: 0.05,
      disgust: 0.1
    },
    confidence: 0.85,
    timestamp: Date.now() - 259200000 // 3 days ago
  },
  {
    text: "Meeting with the team today to discuss our new strategy for Q4.",
    score: 0.05,
    sentiment: 'neutral',
    emotions: {
      joy: 0.2,
      sadness: 0.1,
      anger: 0.1,
      fear: 0.2,
      surprise: 0.2,
      love: 0.1,
      disgust: 0.1
    },
    confidence: 0.72,
    timestamp: Date.now() - 345600000 // 4 days ago
  },
  {
    text: "Just watched the most incredible movie! The plot was fantastic and the acting was superb.",
    score: 0.9,
    sentiment: 'positive',
    emotions: {
      joy: 0.5,
      sadness: 0.05,
      anger: 0.01,
      fear: 0.04,
      surprise: 0.3,
      love: 0.08,
      disgust: 0.02
    },
    confidence: 0.91,
    timestamp: Date.now() - 432000000 // 5 days ago
  }
];

/**
 * Get analysis history
 * This is a mock function that would normally fetch from an API or database
 */
export async function getAnalysisHistory(): Promise<SentimentResult[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return [...mockHistoryData];
}

/**
 * Save analysis to history
 * This is a mock function that would normally save to an API or database
 */
export async function saveAnalysis(result: SentimentResult): Promise<void> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // In a real app, this would save to persistent storage
  console.log('Analysis saved:', result);
}

/**
 * Delete an analysis from history
 * This is a mock function that would normally delete from an API or database
 */
export async function deleteAnalysis(timestamp: number): Promise<void> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // In a real app, this would delete from persistent storage
  console.log('Analysis deleted:', timestamp);
}