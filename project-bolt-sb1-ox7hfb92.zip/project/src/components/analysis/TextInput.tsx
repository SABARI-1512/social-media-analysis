import React, { useState } from 'react';
import { Search, Twitter, Facebook, Instagram, Trash, Loader2 } from 'lucide-react';

interface TextInputProps {
  onAnalyze: (text: string) => void;
  isLoading: boolean;
}

const TextInput: React.FC<TextInputProps> = ({ onAnalyze, isLoading }) => {
  const [text, setText] = useState('');
  const [source, setSource] = useState('custom');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyze(text);
  };

  const handleClear = () => {
    setText('');
  };

  return (
    <div className="card">
      <h2 className="text-xl font-semibold mb-4">Analyze Text</h2>
      
      {/* Source selector */}
      <div className="flex mb-4 border rounded-md overflow-hidden">
        <button
          className={`flex-1 py-2 text-center text-sm flex justify-center items-center transition-colors
            ${source === 'custom' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}
          onClick={() => setSource('custom')}
        >
          <Search size={16} className="mr-2" />
          Custom Text
        </button>
        
        <button
          className={`flex-1 py-2 text-center text-sm flex justify-center items-center transition-colors
            ${source === 'twitter' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}
          onClick={() => setSource('twitter')}
        >
          <Twitter size={16} className="mr-2" />
          Twitter
        </button>
        
        <button
          className={`flex-1 py-2 text-center text-sm flex justify-center items-center transition-colors
            ${source === 'facebook' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}
          onClick={() => setSource('facebook')}
        >
          <Facebook size={16} className="mr-2" />
          Facebook
        </button>
        
        <button
          className={`flex-1 py-2 text-center text-sm flex justify-center items-center transition-colors
            ${source === 'instagram' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}
          onClick={() => setSource('instagram')}
        >
          <Instagram size={16} className="mr-2" />
          Instagram
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="relative mb-4">
          <textarea
            className="input-field min-h-[160px] resize-y pr-10"
            placeholder={getPlaceholder(source)}
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={isLoading}
          />
          {text && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              aria-label="Clear text"
            >
              <Trash size={18} />
            </button>
          )}
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!text.trim() || isLoading}
            className="btn btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Analyze Sentiment'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

function getPlaceholder(source: string): string {
  switch (source) {
    case 'twitter':
      return 'Paste Tweet URL or content here...';
    case 'facebook':
      return 'Paste Facebook post URL or content here...';
    case 'instagram':
      return 'Paste Instagram caption or comments here...';
    default:
      return 'Enter or paste text to analyze emotions and sentiment...';
  }
}

export default TextInput;