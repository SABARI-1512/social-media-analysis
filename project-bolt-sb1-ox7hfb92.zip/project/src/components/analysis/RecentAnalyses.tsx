import React from 'react';
import { Clock, Clipboard } from 'lucide-react';
import { SentimentResult } from '../../types/sentiment';
import EmptyState from '../ui/EmptyState';

interface RecentAnalysesProps {
  analyses: SentimentResult[];
}

const RecentAnalyses: React.FC<RecentAnalysesProps> = ({ analyses }) => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Could add a toast notification here
  };

  return (
    <div className="card h-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Recent Analyses</h3>
        <Clock className="h-5 w-5 text-gray-400" />
      </div>
      
      {analyses.length > 0 ? (
        <div className="space-y-4">
          {analyses.map((analysis, index) => (
            <div 
              key={index}
              className="p-3 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              <div className="flex justify-between items-start mb-2">
                <p className="text-sm truncate max-w-[80%]">
                  {analysis.text.substring(0, 50)}
                  {analysis.text.length > 50 ? '...' : ''}
                </p>
                <button
                  onClick={() => copyToClipboard(analysis.text)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                  aria-label="Copy text"
                >
                  <Clipboard className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex justify-between items-center">
                <span className={`text-xs px-2 py-1 rounded-full ${getSentimentBadgeColor(analysis.sentiment)}`}>
                  {analysis.sentiment}
                </span>
                <span className="text-xs text-gray-500">
                  {new Date(analysis.timestamp).toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No recent analyses"
          description="Your recent analyses will appear here"
          icon="clipboard"
          small
        />
      )}
    </div>
  );
};

function getSentimentBadgeColor(sentiment: string): string {
  switch (sentiment) {
    case 'positive':
      return 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300';
    case 'negative':
      return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300';
    case 'neutral':
    default:
      return 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300';
  }
}

export default RecentAnalyses;