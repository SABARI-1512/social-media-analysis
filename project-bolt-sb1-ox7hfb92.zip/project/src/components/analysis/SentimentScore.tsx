import React from 'react';
import { ThumbsUp, ThumbsDown, Minus } from 'lucide-react';
import { Sentiment } from '../../types/sentiment';

interface SentimentScoreProps {
  score: number; // -1 to 1
  confidence: number; // 0 to 1
  sentiment: Sentiment;
}

const SentimentScore: React.FC<SentimentScoreProps> = ({ 
  score, 
  confidence,
  sentiment
}) => {
  // Normalize score from -1...1 to 0...100
  const normalizedScore = ((score + 1) / 2) * 100;
  
  return (
    <div className="card h-full">
      <h3 className="text-lg font-medium mb-4">Overall Sentiment</h3>
      
      <div className="flex flex-col items-center">
        {/* Sentiment indicator */}
        <div className="mb-4">
          {sentiment === 'positive' && (
            <div className="bg-green-100 dark:bg-green-900/30 p-4 rounded-full">
              <ThumbsUp className="h-10 w-10 text-green-600 dark:text-green-400" />
            </div>
          )}
          
          {sentiment === 'negative' && (
            <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-full">
              <ThumbsDown className="h-10 w-10 text-red-600 dark:text-red-400" />
            </div>
          )}
          
          {sentiment === 'neutral' && (
            <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-full">
              <Minus className="h-10 w-10 text-blue-600 dark:text-blue-400" />
            </div>
          )}
        </div>
        
        {/* Sentiment label */}
        <div className="text-center mb-4">
          <p className="text-2xl font-bold capitalize mb-1">{sentiment}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {getSentimentDescription(score)}
          </p>
        </div>
        
        {/* Score gauge */}
        <div className="w-full mt-2">
          <div className="relative h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className={`absolute top-0 left-0 h-full ${getSentimentColor(sentiment)}`}
              style={{ 
                width: `${normalizedScore}%`,
                transition: 'width 1s ease-out'
              }}
            ></div>
          </div>
          
          <div className="flex justify-between text-xs mt-1 text-gray-500">
            <span>Negative</span>
            <span>Neutral</span>
            <span>Positive</span>
          </div>
        </div>
        
        {/* Confidence score */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Confidence</p>
          <p className="text-lg font-bold">{Math.round(confidence * 100)}%</p>
        </div>
      </div>
    </div>
  );
};

function getSentimentColor(sentiment: Sentiment): string {
  switch (sentiment) {
    case 'positive':
      return 'bg-green-500';
    case 'negative':
      return 'bg-red-500';
    case 'neutral':
    default:
      return 'bg-blue-500';
  }
}

function getSentimentDescription(score: number): string {
  if (score >= 0.6) return 'Strongly positive';
  if (score >= 0.2) return 'Moderately positive';
  if (score > -0.2) return 'Neutral or mixed';
  if (score > -0.6) return 'Moderately negative';
  return 'Strongly negative';
}

export default SentimentScore;