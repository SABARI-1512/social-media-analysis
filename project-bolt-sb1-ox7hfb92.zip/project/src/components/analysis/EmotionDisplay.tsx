import React from 'react';
import { 
  Smile, 
  Frown, 
  Meh, 
  Heart, 
  AlertTriangle, 
  Zap, 
  Check, 
  Coffee 
} from 'lucide-react';
import { Emotion } from '../../types/sentiment';

interface EmotionDisplayProps {
  emotions: Record<Emotion, number>;
}

const EmotionDisplay: React.FC<EmotionDisplayProps> = ({ emotions }) => {
  // Convert emotions object to array for sorting
  const emotionEntries = Object.entries(emotions) as [Emotion, number][];
  
  // Sort by highest score
  const sortedEmotions = emotionEntries.sort((a, b) => b[1] - a[1]);
  
  return (
    <div className="card h-full">
      <h3 className="text-lg font-medium mb-4">Emotion Breakdown</h3>
      
      <div className="space-y-4">
        {sortedEmotions.map(([emotion, score]) => (
          <div key={emotion} className="scale-in" style={{ animationDelay: '0.1s' }}>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                {getEmotionIcon(emotion)}
                <span className="ml-2 capitalize">{emotion}</span>
              </div>
              <span className="text-sm font-medium">{Math.round(score * 100)}%</span>
            </div>
            
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${getEmotionColor(emotion)}`}
                style={{ width: `${score * 100}%`, transition: 'width 1s ease-out' }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

function getEmotionIcon(emotion: Emotion) {
  const className = "h-5 w-5";
  
  switch (emotion) {
    case 'joy':
      return <Smile className={`${className} text-yellow-500`} />;
    case 'sadness':
      return <Frown className={`${className} text-blue-500`} />;
    case 'anger':
      return <Zap className={`${className} text-red-500`} />;
    case 'fear':
      return <AlertTriangle className={`${className} text-purple-500`} />;
    case 'surprise':
      return <Meh className={`${className} text-teal-500`} />;
    case 'love':
      return <Heart className={`${className} text-pink-500`} />;
    case 'disgust':
      return <Coffee className={`${className} text-green-500`} />;
    default:
      return <Check className={`${className} text-gray-500`} />;
  }
}

function getEmotionColor(emotion: Emotion): string {
  switch (emotion) {
    case 'joy':
      return 'bg-yellow-500';
    case 'sadness':
      return 'bg-blue-500';
    case 'anger':
      return 'bg-red-500';
    case 'fear':
      return 'bg-purple-500';
    case 'surprise':
      return 'bg-teal-500';
    case 'love':
      return 'bg-pink-500';
    case 'disgust':
      return 'bg-green-500';
    default:
      return 'bg-gray-500';
  }
}

export default EmotionDisplay;