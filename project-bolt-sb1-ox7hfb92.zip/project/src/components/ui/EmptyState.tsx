import React from 'react';
import { 
  FileQuestion, 
  ClipboardList, 
  History, 
  Search,
  AlertCircle 
} from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon: string;
  small?: boolean;
}

const EmptyState: React.FC<EmptyStateProps> = ({ 
  title, 
  description, 
  icon,
  small = false
}) => {
  const renderIcon = () => {
    const size = small ? 32 : 48;
    const className = "text-gray-400";
    
    switch (icon) {
      case 'clipboard':
        return <ClipboardList size={size} className={className} />;
      case 'history':
        return <History size={size} className={className} />;
      case 'search':
        return <Search size={size} className={className} />;
      case 'alert':
        return <AlertCircle size={size} className={className} />;
      default:
        return <FileQuestion size={size} className={className} />;
    }
  };

  return (
    <div className={`
      flex flex-col items-center justify-center text-center p-4
      ${small ? 'py-6' : 'py-12'}
    `}>
      <div className={`mb-4 ${small ? 'mb-2' : 'mb-4'}`}>
        {renderIcon()}
      </div>
      <h3 className={`font-medium ${small ? 'text-base mb-1' : 'text-lg mb-2'}`}>
        {title}
      </h3>
      <p className={`text-gray-500 max-w-sm ${small ? 'text-sm' : ''}`}>
        {description}
      </p>
    </div>
  );
};

export default EmptyState;