import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LineChart,
  History,
  Heart,
  HelpCircle,
  Settings,
  Share2,
  BarChart3,
  PieChart
} from 'lucide-react';

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ to, icon, label, isActive }) => (
  <Link
    to={to}
    className={`
      flex items-center px-4 py-3 mb-1 rounded-md transition-colors
      ${isActive 
        ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' 
        : 'hover:bg-gray-100 dark:hover:bg-gray-700/50'}
    `}
  >
    <span className="mr-3">{icon}</span>
    <span>{label}</span>
  </Link>
);

const Sidebar: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: <LineChart size={20} /> },
    { path: '/history', label: 'History', icon: <History size={20} /> },
    { path: '/insights', label: 'Insights', icon: <BarChart3 size={20} /> },
    { path: '/compare', label: 'Compare', icon: <PieChart size={20} /> },
    { path: '/favorites', label: 'Favorites', icon: <Heart size={20} /> },
    { path: '/share', label: 'Share', icon: <Share2 size={20} /> },
  ];

  return (
    <div className="h-full pt-20 pb-4 flex flex-col">
      <div className="px-4 mb-8">
        <h2 className="text-xl font-bold mb-2">Emotion Decoder</h2>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Analyze and understand social sentiments
        </p>
      </div>
      
      <nav className="flex-1 px-2 overflow-y-auto">
        <div className="mb-6">
          <p className="px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
            Main
          </p>
          
          {navItems.map(item => (
            <NavItem
              key={item.path}
              to={item.path}
              icon={item.icon}
              label={item.label}
              isActive={currentPath === item.path}
            />
          ))}
        </div>
        
        <div>
          <p className="px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
            Support
          </p>
          
          <NavItem
            to="/about"
            icon={<HelpCircle size={20} />}
            label="About"
            isActive={currentPath === '/about'}
          />
          
          <NavItem
            to="/settings"
            icon={<Settings size={20} />}
            label="Settings"
            isActive={currentPath === '/settings'}
          />
        </div>
      </nav>
      
      <div className="px-4 mt-auto">
        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <p className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
            Pro Tip
          </p>
          <p className="text-xs text-gray-600 dark:text-gray-400">
            Analyze longer conversations for more accurate emotion insights.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;