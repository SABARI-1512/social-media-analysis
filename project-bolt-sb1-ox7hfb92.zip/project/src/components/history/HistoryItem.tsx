import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Download, 
  Share2, 
  Trash2,
  ThumbsUp,
  ThumbsDown,
  Minus
} from 'lucide-react';
import { SentimentResult } from '../../types/sentiment';

interface HistoryItemProps {
  item: SentimentResult;
}

const HistoryItem: React.FC<HistoryItemProps> = ({ item }) => {
  const [expanded, setExpanded] = useState(false);

  const handleDelete = () => {
    // Implement delete functionality
    console.log('Delete item', item);
  };

  const handleExport = () => {
    // Implement export functionality
    console.log('Export item', item);
  };

  const handleShare = () => {
    // Implement share functionality
    console.log('Share item', item);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  // Determine which icon to show based on sentiment
  const renderSentimentIcon = () => {
    switch (item.sentiment) {
      case 'positive':
        return <ThumbsUp className="h-5 w-5 text-green-500" />;
      case 'negative':
        return <ThumbsDown className="h-5 w-5 text-red-500" />;
      default:
        return <Minus className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="card hover:shadow transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex items-center">
          <div className="mr-4">
            {renderSentimentIcon()}
          </div>
          
          <div>
            <p className="font-medium">
              {item.text.length > 100 
                ? `${item.text.substring(0, 100)}...` 
                : item.text}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {formatDate(item.timestamp)}
            </p>
          </div>
        </div>
        
        <button
          onClick={() => setExpanded(!expanded)}
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          aria-label={expanded ? 'Show less' : 'Show more'}
        >
          {expanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </button>
      </div>
      
      {expanded && (
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 slide-up">
          {/* Emotion breakdown */}
          <div className="mb-4">
            <h4 className="text-sm font-semibold mb-2">Emotion Breakdown</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Object.entries(item.emotions).map(([emotion, score]) => (
                <div 
                  key={emotion}
                  className="bg-gray-50 dark:bg-gray-800 p-2 rounded"
                >
                  <div className="text-xs text-gray-500 dark:text-gray-400 capitalize">{emotion}</div>
                  <div className="font-medium">{Math.round(score * 100)}%</div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="flex justify-end space-x-2 mt-4">
            <button
              onClick={handleDelete}
              className="p-2 text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20 rounded"
            >
              <Trash2 size={16} />
            </button>
            
            <button
              onClick={handleExport}
              className="p-2 text-sm text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded"
            >
              <Download size={16} />
            </button>
            
            <button
              onClick={handleShare}
              className="p-2 text-sm text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded"
            >
              <Share2 size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryItem;