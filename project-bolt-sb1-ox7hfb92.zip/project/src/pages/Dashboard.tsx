import React, { useState } from 'react';
import TextInput from '../components/analysis/TextInput';
import EmotionDisplay from '../components/analysis/EmotionDisplay';
import SentimentScore from '../components/analysis/SentimentScore';
import RecentAnalyses from '../components/analysis/RecentAnalyses';
import { analyzeText } from '../services/sentimentService';
import { SentimentResult } from '../types/sentiment';

const Dashboard: React.FC = () => {
  const [result, setResult] = useState<SentimentResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [recentAnalyses, setRecentAnalyses] = useState<SentimentResult[]>([]);

  const handleAnalyze = async (text: string) => {
    if (!text.trim()) return;
    
    setLoading(true);
    try {
      const analysisResult = await analyzeText(text);
      setResult(analysisResult);
      
      // Add to recent analyses
      setRecentAnalyses(prev => {
        const newAnalyses = [analysisResult, ...prev].slice(0, 5);
        return newAnalyses;
      });
    } catch (error) {
      console.error('Analysis error:', error);
      // Could add error handling UI here
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="mb-8 text-center">Emotion Decoder</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TextInput onAnalyze={handleAnalyze} isLoading={loading} />
          
          {result && (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 slide-up">
              <EmotionDisplay emotions={result.emotions} />
              <SentimentScore 
                score={result.score} 
                confidence={result.confidence}
                sentiment={result.sentiment} 
              />
            </div>
          )}
        </div>
        
        <div>
          <RecentAnalyses analyses={recentAnalyses} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;