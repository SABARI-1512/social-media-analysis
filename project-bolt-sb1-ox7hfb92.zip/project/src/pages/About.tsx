import React from 'react';
import { BookOpen, Heart, Shield, Zap } from 'lucide-react';

const AboutCard: React.FC<{
  title: string;
  description: string;
  icon: React.ReactNode;
  className?: string;
}> = ({ title, description, icon, className }) => (
  <div className={`card hover:shadow-lg transition-shadow ${className}`}>
    <div className="flex items-start">
      <div className="mr-4 p-3 rounded-full bg-blue-100 dark:bg-blue-900/30">
        {icon}
      </div>
      <div>
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-300">{description}</p>
      </div>
    </div>
  </div>
);

const About: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="mb-4">About Emotion Decoder</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Decode the emotions hidden in social media conversations with advanced sentiment analysis.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 fade-in">
        <AboutCard
          title="How It Works"
          description="Our advanced AI analyzes text to identify emotions and sentiment, breaking down the emotional tone into specific categories like joy, anger, fear, and more."
          icon={<Zap className="h-6 w-6 text-blue-600 dark:text-blue-400" />}
        />
        
        <AboutCard
          title="Privacy First"
          description="We value your privacy. Your analyzed content is never stored permanently and all processing happens securely without sharing data with third parties."
          icon={<Shield className="h-6 w-6 text-blue-600 dark:text-blue-400" />}
        />
        
        <AboutCard
          title="Learning Resource"
          description="Emotion Decoder helps you understand social dynamics and improve your emotional intelligence by revealing the sentiment behind conversations."
          icon={<BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />}
        />
        
        <AboutCard
          title="Continuous Improvement"
          description="Our sentiment analysis models are constantly improving through machine learning to provide more accurate and nuanced emotional analysis."
          icon={<Heart className="h-6 w-6 text-blue-600 dark:text-blue-400" />}
        />
      </div>

      <div className="card text-center p-10 mb-8">
        <h2 className="mb-6">Try Emotion Decoder Today</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
          Understand the emotional context of social media conversations, customer feedback, 
          or any text-based communication with our powerful sentiment analysis tool.
        </p>
        <a href="/" className="btn btn-primary inline-block">
          Start Analyzing
        </a>
      </div>
    </div>
  );
};

export default About;