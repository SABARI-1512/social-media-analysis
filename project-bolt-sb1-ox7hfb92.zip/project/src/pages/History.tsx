import React, { useState, useEffect } from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { getAnalysisHistory } from '../services/historyService';
import { SentimentResult } from '../types/sentiment';
import HistoryItem from '../components/history/HistoryItem';
import EmptyState from '../components/ui/EmptyState';

const History: React.FC = () => {
  const [history, setHistory] = useState<SentimentResult[]>([]);
  const [filteredHistory, setFilteredHistory] = useState<SentimentResult[]>([]);
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const fetchHistory = async () => {
      const data = await getAnalysisHistory();
      setHistory(data);
      setFilteredHistory(data);
    };
    
    fetchHistory();
  }, []);

  useEffect(() => {
    if (filter === 'all') {
      setFilteredHistory(history);
    } else {
      setFilteredHistory(history.filter(item => item.sentiment === filter));
    }
    setPage(1); // Reset to first page when filter changes
  }, [filter, history]);

  const handleFilterChange = (newFilter: string) => {
    setFilter(newFilter);
  };

  const totalPages = Math.ceil(filteredHistory.length / itemsPerPage);
  const paginatedHistory = filteredHistory.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1>Analysis History</h1>
        <div className="flex items-center space-x-4">
          <Calendar className="h-5 w-5 text-gray-500" />
          <select 
            className="input-field max-w-xs"
            value={filter}
            onChange={(e) => handleFilterChange(e.target.value)}
          >
            <option value="all">All Sentiments</option>
            <option value="positive">Positive</option>
            <option value="neutral">Neutral</option>
            <option value="negative">Negative</option>
          </select>
        </div>
      </div>

      {paginatedHistory.length > 0 ? (
        <div className="space-y-4 fade-in">
          {paginatedHistory.map((item, index) => (
            <HistoryItem key={index} item={item} />
          ))}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center mt-8 space-x-2">
              <button
                onClick={() => setPage(prev => Math.max(prev - 1, 1))}
                disabled={page === 1}
                className="p-2 rounded-md disabled:opacity-50 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              
              <span className="text-sm">
                Page {page} of {totalPages}
              </span>
              
              <button
                onClick={() => setPage(prev => Math.min(prev + 1, totalPages))}
                disabled={page === totalPages}
                className="p-2 rounded-md disabled:opacity-50 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
      ) : (
        <EmptyState
          title="No analysis history"
          description="Your previous analyses will appear here once you've analyzed some text."
          icon="history"
        />
      )}
    </div>
  );
};

export default History;