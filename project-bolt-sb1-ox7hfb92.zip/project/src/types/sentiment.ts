export type Emotion = 'joy' | 'sadness' | 'anger' | 'fear' | 'surprise' | 'love' | 'disgust';
export type Sentiment = 'positive' | 'negative' | 'neutral';

export interface SentimentResult {
  text: string;
  score: number; // -1 to 1 where -1 is very negative, 1 is very positive
  sentiment: Sentiment;
  emotions: Record<Emotion, number>; // Values from 0 to 1 indicating strength
  confidence: number; // 0 to 1
  timestamp: number;
}